<?php
class Conecta
{
    private static $conexion;

    public static function conectarBD()
    {
        if (!self::$conexion) {
<<<<<<< HEAD
            self::$conexion = mysqli_connect('localhost', 'root', '12345678', 'muebleria_m');
=======
            self::$conexion = mysqli_connect('localhost', 'root', 'root', 'muebleria_m2');
>>>>>>> 2dd8a71c2959956971ed99674d73e5e4ea60e017
            if (!self::$conexion) {
                die("Error al conectar a la base de datos: " . mysqli_connect_error());
            }
        }
        return self::$conexion;
    }

    public static function desConectaBD()
    {
        if (self::$conexion) {
            mysqli_close(self::$conexion);
            self::$conexion = null;
        }
    }
    public static function debuguearConexion()
    {
        echo("<pre>");
        var_dump(self::$conexion);
        echo("</pre>");
    }
}
// pruebas
// conecta::conectarBD();
// conecta::debuguearConexion();
// conecta::desConectaBD();
?>
