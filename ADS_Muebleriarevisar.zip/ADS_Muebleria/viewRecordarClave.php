<?php
include("securityModule/RecordarClave/formIngresarUsuario.php");

$objFormIngresarUsuario = new FormIngresarUsuario();
$objFormIngresarUsuario->formIngresarUsuarioShow();
?>
